import ast
import io
import re
import tokenize
from importlib.machinery import PathFinder
from pathlib import Path

_SYSTEM = "system"
_LOCAL = "local"


def list_imported_modules(filename: str) -> dict[str, list[str]]:
    imports: dict[str, set[str]] = {_SYSTEM: set(), _LOCAL: set()}
    checked_files: set[str] = set()
    root_dir = str(Path(filename).parent)
    _list_imported_modules(imports, filename, checked_files, root_dir)
    return {
        _SYSTEM: sorted(imports[_SYSTEM]),
        _LOCAL: sorted(imports[_LOCAL]),
    }


# Python source encoding


def _decode_python_source(source: bytes) -> str:
    bom = b"\xef\xbb\xbf" if source.startswith(b"\xef\xbb\xbf") else b""
    body = source[len(bom) :]
    header = b"\n".join(re.split(rb"\r\n|\r|\n", body, maxsplit=2)[:2])
    # Keep Python 3.11 from decoding an initial non-ASCII comment as UTF-8
    # before it reaches the encoding declaration on the second physical line.
    header = bom + re.sub(rb"[\x80-\xff]", b"?", header)
    encoding, _ = tokenize.detect_encoding(io.BytesIO(header).readline)
    return source.decode(encoding)


def _normalize_python_source_encoding(text: str) -> str:
    # The decoded text may have new physical lines (for example, with UTF-7).
    # Change only a declaration that will be active when this text is saved.
    lines = re.split(r"(\r\n|\r|\n)", text, maxsplit=2)
    for position in range(0, min(len(lines), 4), 2):
        line = lines[position]
        # PEP 263 encoding declarations occupy a comment-only physical line.
        cookie = re.match(r"^[ \t\f]*#.*?coding[:=][ \t]*([-_.a-zA-Z0-9]+)", line)
        if cookie:
            start, end = cookie.span(1)
            lines[position] = line[:start] + "utf-8" + line[end:]
            break
        if not re.match(r"^[ \t\f]*(?:#|$)", line):
            break
    return "".join(lines)


# Recursive import discovery


def _list_imported_modules(
    imports: dict[str, set[str]],
    filename: str,
    checked_files: set[str],
    root_dir: str,
) -> None:
    # Keep import paths lexical; resolve only the visitation identity.
    resolved_filename = str(Path(filename).resolve())
    if resolved_filename in checked_files:
        return
    checked_files.add(resolved_filename)

    dir_path = str(Path(filename).parent)
    try:
        root = ast.parse(Path(filename).read_bytes())
    except (SyntaxError, UnicodeDecodeError):
        return

    for node in ast.walk(root):
        if isinstance(node, ast.Import):
            for alias in node.names:
                _track_module(
                    imports, checked_files, dir_path, 0, alias.name, root_dir=root_dir
                )

        elif isinstance(node, ast.ImportFrom):
            if node.module:
                is_local = _track_module(
                    imports,
                    checked_files,
                    dir_path,
                    node.level,
                    node.module,
                    root_dir=root_dir,
                )

                # Track from-import targets that resolve as modules.
                for alias in node.names:
                    target = f"{node.module}.{alias.name}"
                    _track_module(
                        imports,
                        checked_files,
                        dir_path,
                        node.level,
                        target,
                        root_dir=root_dir,
                        allow_system=(
                            node.level == 0
                            and not is_local
                            and _is_importable_module(target)
                        ),
                    )
            else:
                # Track relative imports without module names, such as "from . import foo".
                for alias in node.names:
                    _track_module(
                        imports,
                        checked_files,
                        dir_path,
                        node.level,
                        alias.name,
                        root_dir=root_dir,
                    )


def _track_module(
    imports: dict[str, set[str]],
    checked_files: set[str],
    dir_path: str,
    level: int,
    name: str,
    *,
    root_dir: str,
    allow_system: bool = True,
) -> bool:
    # Absolute imports use the startup directory throughout package recursion.
    if level == 0:
        dir_path = root_dir
    module_path = _resolve_module_path(dir_path, level, name)
    module_filename = _to_module_filename(module_path)

    if module_filename:
        parts = name.split(".")
        module_files = []
        for index in range(1, len(parts)):
            parent_path = _resolve_module_path(dir_path, level, ".".join(parts[:index]))
            init_file = Path(parent_path) / "__init__.py"
            if init_file.is_file():
                module_files.append(str(init_file))
        module_files.append(module_filename)

        for filename in module_files:
            imports[_LOCAL].add(str(Path(filename).absolute()))
            _list_imported_modules(imports, filename, checked_files, root_dir)
        return True
    elif allow_system and level == 0:
        # Only absolute imports can resolve as system modules.
        imports[_SYSTEM].add(name)
    return False


# Module path resolution


def _to_module_filename(module_path: str) -> str | None:
    filename = Path(f"{module_path}.py")
    if filename.is_file():
        return str(filename)
    module_dir = Path(module_path)
    init_file = module_dir / "__init__.py"
    if module_dir.is_dir() and init_file.is_file():
        return str(init_file)
    return None


def _resolve_module_path(dir_path: str, level: int, name: str) -> str:
    path = Path(dir_path)
    for _ in range(level - 1):
        path = path / ".."
    for part in name.split("."):
        path = path / part
    return str(path)


def _is_importable_module(name: str) -> bool:
    search_path = None
    parts = name.split(".")
    for index in range(len(parts)):
        fullname = ".".join(parts[: index + 1])
        spec = PathFinder.find_spec(fullname, search_path)
        if spec is None:
            return False
        if index < len(parts) - 1 and spec.submodule_search_locations is None:
            return False
        search_path = spec.submodule_search_locations
    return True
