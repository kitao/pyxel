import pyxel

from .canvas_panel import CanvasPanel
from .editor_base import EditorBase
from .image_viewer import ImageViewer
from .settings import EDITOR_IMAGE, TEXT_LABEL_COLOR, TOOL_PENCIL
from .tilemap_viewer import TilemapViewer
from .widgets import NumberPicker, RadioButton


class TilemapEditor(EditorBase):
    # Variables:
    #   color_var
    #   tool_var
    #   image_index_var
    #   canvas_var
    #   focus_x_var
    #   focus_y_var
    #   help_message_var
    #
    #   tilemap_index_var
    #   tile_x_var
    #   tile_y_var
    #   tile_w_var
    #   tile_h_var
    #
    # Events:
    #   undo (data)
    #   redo (data)
    #   drop (filename)

    def __init__(self, parent):
        super().__init__(parent)
        self.new_var("canvas_var", None)
        self.add_var_event_listener("canvas_var", "get", self.__on_canvas_get)
        self.new_var("color_var", (255, 255))

        self._tool_button = RadioButton(
            self,
            81,
            161,
            img=EDITOR_IMAGE,
            u=63,
            v=0,
            num_buttons=7,
            value=TOOL_PENCIL,
        )
        self.add_tool_button_help(self._tool_button)
        self.copy_var("tool_var", self._tool_button, "value_var")

        self._tilemap_picker = NumberPicker(
            self, 48, 161, min_value=0, max_value=pyxel.NUM_TILEMAPS - 1, value=0
        )
        self._tilemap_picker.add_event_listener(
            "change", self.__on_tilemap_picker_change
        )
        self._tilemap_picker.add_event_listener(
            "mouse_hover", self.__on_tilemap_picker_mouse_hover
        )
        self.add_number_picker_help(self._tilemap_picker)
        self.copy_var("tilemap_index_var", self._tilemap_picker, "value_var")

        self._tilemap_viewer = TilemapViewer(self)
        self.copy_var("focus_x_var", self._tilemap_viewer)
        self.copy_var("focus_y_var", self._tilemap_viewer)

        self._image_picker = NumberPicker(
            self,
            192,
            161,
            min_value=0,
            max_value=pyxel.NUM_IMAGES - 1,
            value=0,
            allow_out_of_range=True,
        )
        self._image_picker.add_event_listener("change", self.__on_image_picker_change)
        self.add_number_picker_help(self._image_picker)
        self.copy_var("image_index_var", self._image_picker, "value_var")
        self._sync_image_picker()

        self._image_viewer = ImageViewer(self)
        self.copy_var("tile_x_var", self._image_viewer, "focus_x_var")
        self.copy_var("tile_y_var", self._image_viewer, "focus_y_var")
        self.copy_var("tile_w_var", self._image_viewer, "focus_w_var")
        self.copy_var("tile_h_var", self._image_viewer, "focus_h_var")
        self._canvas_panel = CanvasPanel(self)

        self.add_event_listener("undo", self.__on_undo)
        self.add_event_listener("redo", self.__on_redo)
        self.add_event_listener("drop", self.__on_drop)
        self.add_event_listener("update", self.__on_update)
        self.add_event_listener("draw", self.__on_draw)

    # Public methods

    def refresh_resource(self):
        self._tilemap_picker.set_bank_size(len(pyxel.tilemaps))
        self._image_picker.set_bank_size(len(pyxel.images))
        self._sync_image_picker()

    # Helpers

    def _sync_image_picker(self):
        source = self.canvas_var.imgsrc
        # A directly assigned Image has no bank number to show in the picker.
        self.image_index_var = source if isinstance(source, int) else -1

    def _restore_state(self, data, prefix):
        self.tilemap_index_var = data["tilemap_index"]
        x, y = data.get("focus_pos", (0, 0))
        if "focus_pos" in data:
            self.focus_x_var, self.focus_y_var = x, y
        self.canvas_var.set_slice(x * 8, y * 8, data[f"{prefix}_data"])
        if f"{prefix}_imgsrc" in data:
            self.canvas_var.imgsrc = data[f"{prefix}_imgsrc"]
            self._sync_image_picker()

    # Event handlers

    def __on_canvas_get(self, value):
        return pyxel.tilemaps[self.tilemap_index_var]

    def __on_tilemap_picker_change(self, value):
        self._sync_image_picker()

    def __on_tilemap_picker_mouse_hover(self, _x, _y):
        self.help_message_var = "COPY_ALL:CTRL+SHIFT+C/X/V"

    def __on_image_picker_change(self, value):
        if value >= 0:
            self.canvas_var.imgsrc = value

    def __on_undo(self, data):
        self._restore_state(data, "old")

    def __on_redo(self, data):
        self._restore_state(data, "new")

    def __on_drop(self, filename):
        self._release_capture()
        try:
            tilemap = pyxel.Tilemap.from_tmx(filename, 0)
        except Exception as e:  # noqa: BLE001 - Native loaders raise plain Exception.
            print(f"Failed to load tilemap: {e}")
            return
        self._canvas_panel.paste_at_focus(tilemap)

    def __on_update(self):
        self._sync_image_picker()
        self.check_tool_button_shortcuts()

    def __on_draw(self):
        self.draw_panel(11, 156, 136, 17)
        self.draw_panel(157, 156, 72, 17)
        pyxel.text(18, 162, "TILEMAP", TEXT_LABEL_COLOR)
        pyxel.text(170, 162, "IMAGE", TEXT_LABEL_COLOR)
