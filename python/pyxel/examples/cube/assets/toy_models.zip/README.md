# c06 toy models

Open a .bbmodel project in Blockbench to reshape a toy or paint its embedded texture.
Export binary glTF with scale 1 and embedded textures, without an armature.
The two 64 x 64 textures use Pyxel's default palette. Faces use compact painted tiles.
The stage's mesh supplies the fixed floor and building-frame collision.
Moving toys use sphere, capsule, box, or rounded-box colliders matching their shapes.

The Toys group in toy_stage.bbmodel places the loose objects. Each child group is named for its model (block, plank, ball, domino, or roller); move its pivot to arrange the stack.
